document.addEventListener("DOMContentLoaded", () => {
    const bookingForm = document.querySelector(".booking-form");
    const bookingSection = document.getElementById("book-trip");

    
    const pricingRules = {
        local: { multiplier: 1, currency: "LKR", basePrice: 2000, label: "Local Resident Rates Apply" },
        foreign: { multiplier: 3.35, currency: "USD", basePrice: 20, label: "Standard International Tourist Rates Apply" }
    };

    bookingForm.addEventListener("submit", (e) => {
        e.preventDefault(); 
        
        const destination = document.getElementById("destination").value.trim();
        const travelerType = document.getElementById("traveler-type").value;
        const startDate = document.getElementById("start-date").value;
        const duration = parseInt(document.getElementById("duration").value);
        const travelers = parseInt(document.getElementById("travelers").value);
		const profile = pricingRules[travelerType];
        const totalEstimatedCost = (profile.basePrice * duration * travelers).toLocaleString();
		const oldResult = document.getElementById("itinerary-result");
        if (oldResult) oldResult.remove();
		const resultCard = document.createElement("div");
        resultCard.id = "itinerary-result";
        resultCard.className = "itinerary-card animate-fade-in";

        resultCard.innerHTML = `
            <div class="itinerary-header">
                <i class="fas fa-route"></i>
                <h3>Your Custom Sri Lankan Route is Ready!</h3>
            </div>
            <div class="itinerary-details">
                <p><strong>Proposed Trip:</strong> Custom Exploration around <span>${destination}</span></p>
                <p><strong>Timeline:</strong> Starting on <span>${startDate}</span> for <span>${duration} Days</span></p>
                <p><strong>Party Size:</strong> <span>${travelers} Guest(s)</span> (${profile.label})</p>
                
                <hr class="divider">
                
                <div class="price-breakdown">
                    <h4>Estimated Package Cost:</h4>
                    <p class="price-tag">${profile.currency} ${totalEstimatedCost}</p>
                    <small>*Includes personalized ground transport across ${destination}, driver-guiding configurations, and entry tax estimations mapping to your traveler group profile.</small>
                </div>

                <button class="confirm-booking-btn" onclick="alert('Thank you! Our local Sri Lankan travel agent will contact you within 15 minutes with a finalized day-by-day roadmap.')">
                    <i class="fas fa-paper-plane"></i> Finalize & Lock This Booking
                </button>
            </div>
        `;
		bookingSection.appendChild(resultCard);
        resultCard.scrollIntoView({ behavior: "smooth" });
    });
});
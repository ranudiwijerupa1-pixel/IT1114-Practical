document.addEventListener("DOMContentLoaded", () => {
    
    const form = document.querySelector(".booking-form") || document.querySelector("form");

   
    form.addEventListener("submit", (e) => {
        e.preventDefault();

     
        const destination = document.getElementById("destination").value.trim();
        const travelerType = document.getElementById("traveler-type").value;
        const startDate = document.getElementById("start-date").value;
        const duration = parseInt(document.getElementById("duration").value) || 0;
        const guests = parseInt(document.getElementById("travelers").value) || 0;
		const basePrice = travelerType === "local" ? 2000 : 20; 
        const currency = travelerType === "local" ? "LKR" : "USD";
        const totalCost = (basePrice * duration * guests).toLocaleString();

       
        alert(`Tour Booked!\nDestination: ${destination}\nTotal Cost: ${currency} ${totalCost}`);
    });
});